
const supabase = window.supabaseClient;

async function getTools() {
  const { data } = await supabase.from("tools").select("*");
  return data;
}
