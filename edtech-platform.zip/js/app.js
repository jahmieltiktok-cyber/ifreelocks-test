
document.addEventListener("DOMContentLoaded", async () => {
  const balance = await getWalletBalance();
  document.getElementById("walletBalance").innerText = balance;

  const tools = await getTools();
  const container = document.getElementById("toolsContainer");

  tools.forEach(tool => {
    const div = document.createElement("div");
    div.innerHTML = `<h3>${tool.title}</h3><p>${tool.description}</p><p>Price: ${tool.price}</p>`;
    container.appendChild(div);
  });
});
