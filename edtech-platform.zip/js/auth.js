
const supabase = window.supabaseClient;

async function signup() {
  const email = document.getElementById("s_email").value;
  const password = document.getElementById("s_password").value;
  const name = document.getElementById("s_name").value;

  const { error } = await supabase.auth.signUp({
    email,
    password,
    options: { data: { full_name: name } }
  });

  if (error) alert(error.message);
  else alert("Signup successful");
}

async function login() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  const { error } = await supabase.auth.signInWithPassword({ email, password });

  if (error) alert(error.message);
  else window.location.href = "dashboard.html";
}

async function logout() {
  await supabase.auth.signOut();
  window.location.href = "login.html";
}
