
const supabase = window.supabaseClient;

async function createTool() {
  const title = document.getElementById("toolTitle").value;
  const description = document.getElementById("toolDesc").value;
  const price = document.getElementById("toolPrice").value;

  const { error } = await supabase.from("tools").insert([{ title, description, price }]);

  if (error) alert(error.message);
  else alert("Tool Created!");
}

async function loadUsers() {
  const { data } = await supabase.from("profiles").select("*");
  const list = document.getElementById("usersList");
  data.forEach(user => {
    const div = document.createElement("div");
    div.innerText = user.full_name + " - " + user.role;
    list.appendChild(div);
  });
}

document.addEventListener("DOMContentLoaded", loadUsers);
