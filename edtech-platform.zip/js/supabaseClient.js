
const supabaseUrl = "YOUR_SUPABASE_URL";
const supabaseKey = "YOUR_PUBLIC_ANON_KEY";
window.supabaseClient = supabase.createClient(supabaseUrl, supabaseKey);
