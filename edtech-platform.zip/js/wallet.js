
const supabase = window.supabaseClient;

async function getWalletBalance() {
  const { data: { user } } = await supabase.auth.getUser();

  const { data } = await supabase
    .from("wallets")
    .select("balance")
    .eq("user_id", user.id)
    .single();

  return data.balance;
}
